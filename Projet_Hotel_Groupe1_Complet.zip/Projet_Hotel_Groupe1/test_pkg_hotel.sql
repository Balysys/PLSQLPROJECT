-- ============================================================
-- PROJET 3 - HOTEL ET RESERVATIONS
-- test_pkg_hotel.sql
-- Auteur: Groupe 1
-- Date: 2026
-- Description: Script de tests complet
-- ============================================================

SET SERVEROUTPUT ON;
SET FEEDBACK ON;

PROMPT '═══════════════════════════════════════════════════════════';
PROMPT '  TESTS PKG_HOTEL';
PROMPT '═══════════════════════════════════════════════════════════';
PROMPT '';

-- ============================================================
-- TEST 1: nb_nuits
-- ============================================================
PROMPT '--- TEST 1: nb_nuits ---';

DECLARE
    l_nb_nuits NUMBER;
BEGIN
    l_nb_nuits := pkg_hotel.nb_nuits(5001);
    DBMS_OUTPUT.PUT_LINE('✅ Réservation 5001: ' || l_nb_nuits || ' nuits');
END;
/

-- Test erreur: réservation inexistante
PROMPT '--- Test erreur: réservation inexistante ---';
DECLARE
    l_nb_nuits NUMBER;
BEGIN
    l_nb_nuits := pkg_hotel.nb_nuits(9999);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✅ Erreur attendue: ' || SQLERRM);
END;
/

-- ============================================================
-- TEST 2: reserver
-- ============================================================
PROMPT '--- TEST 2: reserver ---';

-- Test client VIP
BEGIN
    pkg_hotel.reserver(
        p_client_id => 1002,
        p_chambre_no => 105,
        p_date_arrivee => DATE '2026-09-01',
        p_date_depart => DATE '2026-09-05',
        p_nb_personnes => 2
    );
END;
/

-- Test client non VIP
BEGIN
    pkg_hotel.reserver(
        p_client_id => 1001,
        p_chambre_no => 101,
        p_date_arrivee => DATE '2026-09-10',
        p_date_depart => DATE '2026-09-15',
        p_nb_personnes => 1
    );
END;
/

-- Test erreur: dates incohérentes
PROMPT '--- Test erreur: dates incohérentes ---';
BEGIN
    pkg_hotel.reserver(
        p_client_id => 1001,
        p_chambre_no => 101,
        p_date_arrivee => DATE '2026-09-15',
        p_date_depart => DATE '2026-09-10',
        p_nb_personnes => 1
    );
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✅ Erreur attendue: ' || SQLERRM);
END;
/

-- Test erreur: chambre inexistante
PROMPT '--- Test erreur: chambre inexistante ---';
BEGIN
    pkg_hotel.reserver(
        p_client_id => 1001,
        p_chambre_no => 999,
        p_date_arrivee => DATE '2026-09-15',
        p_date_depart => DATE '2026-09-20',
        p_nb_personnes => 1
    );
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✅ Erreur attendue: ' || SQLERRM);
END;
/

-- Test erreur: client inexistant
PROMPT '--- Test erreur: client inexistant ---';
BEGIN
    pkg_hotel.reserver(
        p_client_id => 9999,
        p_chambre_no => 101,
        p_date_arrivee => DATE '2026-09-15',
        p_date_depart => DATE '2026-09-20',
        p_nb_personnes => 1
    );
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✅ Erreur attendue: ' || SQLERRM);
END;
/

-- ============================================================
-- TEST 3: annuler
-- ============================================================
PROMPT '--- TEST 3: annuler ---';

-- Annulation sans pénalité
BEGIN
    pkg_hotel.annuler(5005);
END;
/

-- Test erreur: réservation déjà annulée
PROMPT '--- Test erreur: réservation déjà annulée ---';
BEGIN
    pkg_hotel.annuler(5005);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✅ Erreur attendue: ' || SQLERRM);
END;
/

-- ============================================================
-- TEST 4: chambres_libres (REF CURSOR)
-- ============================================================
PROMPT '--- TEST 4: chambres_libres ---';

DECLARE
    l_cursor SYS_REFCURSOR;
    l_numero chambre.numero%TYPE;
    l_type chambre.type_ch%TYPE;
    l_etage chambre.etage%TYPE;
    l_prix chambre.prix_nuit%TYPE;
    l_count NUMBER := 0;
BEGIN
    l_cursor := pkg_hotel.chambres_libres(DATE '2026-07-15');
    
    DBMS_OUTPUT.PUT_LINE('Chambres disponibles le 15/07/2026:');
    LOOP
        FETCH l_cursor INTO l_numero, l_type, l_etage, l_prix;
        EXIT WHEN l_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('  Chambre ' || l_numero || ' - ' || l_type || 
                            ' - Étage ' || l_etage || ' - ' || l_prix || ' EUR');
        l_count := l_count + 1;
    END LOOP;
    CLOSE l_cursor;
    DBMS_OUTPUT.PUT_LINE('✅ ' || l_count || ' chambres disponibles');
END;
/

-- ============================================================
-- TEST 5: statistiques
-- ============================================================
PROMPT '--- TEST 5: statistiques ---';
BEGIN
    pkg_hotel.statistiques;
END;
/

-- ============================================================
-- TEST 6: SQL Dynamique
-- ============================================================
PROMPT '--- TEST 6: SQL Dynamique (compter_lignes) ---';
BEGIN
    pkg_hotel.compter_lignes('CHAMBRE');
    pkg_hotel.compter_lignes('CLIENT_HOTEL');
    pkg_hotel.compter_lignes('RESERVATION');
    pkg_hotel.compter_lignes('JOURNAL_RESA');
END;
/

-- ============================================================
-- TEST 7: BULK COLLECT + FORALL
-- ============================================================
PROMPT '--- TEST 7: BULK COLLECT + FORALL ---';

DECLARE
    l_client_ids SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1001, 1002, 1003);
    l_chambre_nos SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(101, 103, 105);
    l_arrivees SYS.ODCIDATELIST := SYS.ODCIDATELIST(
        DATE '2026-10-01', DATE '2026-10-02', DATE '2026-10-03'
    );
    l_departs SYS.ODCIDATELIST := SYS.ODCIDATELIST(
        DATE '2026-10-03', DATE '2026-10-05', DATE '2026-10-06'
    );
    l_nb_personnes SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1, 2, 2);
BEGIN
    pkg_hotel.charger_reservations_massif(
        l_client_ids,
        l_chambre_nos,
        l_arrivees,
        l_departs,
        l_nb_personnes
    );
END;
/

-- ============================================================
-- TEST 8: Vérification du trigger d'audit
-- ============================================================
PROMPT '--- TEST 8: Vérification du trigger d''audit ---';

DECLARE
    l_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO l_count FROM journal_resa;
    DBMS_OUTPUT.PUT_LINE('✅ ' || l_count || ' entrées dans journal_resa');
    
    DBMS_OUTPUT.PUT_LINE('Dernières entrées du journal:');
    FOR l_rec IN (
        SELECT * FROM journal_resa ORDER BY id DESC FETCH FIRST 5 ROWS ONLY
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('  ' || l_rec.action || ' - Client: ' || 
                            l_rec.client_id || ' - Chambre: ' || l_rec.chambre_no);
    END LOOP;
END;
/

-- ============================================================
-- TEST 9: Vérification trigger disponibilité
-- ============================================================
PROMPT '--- TEST 9: Vérification trigger disponibilité ---';

DECLARE
    l_dispo chambre.disponible%TYPE;
BEGIN
    SELECT disponible INTO l_dispo
    FROM chambre
    WHERE numero = 105;
    DBMS_OUTPUT.PUT_LINE('Chambre 105 disponible: ' || l_dispo);
    
    pkg_hotel.annuler(5004);
    
    SELECT disponible INTO l_dispo
    FROM chambre
    WHERE numero = 105;
    DBMS_OUTPUT.PUT_LINE('Chambre 105 après annulation: ' || l_dispo);
END;
/

-- ============================================================
-- ROLLBACK FINAL
-- ============================================================
PROMPT '';
PROMPT '═══════════════════════════════════════════════════════════';
PROMPT '🔄 ROLLBACK - Nettoyage de la base';
PROMPT '═══════════════════════════════════════════════════════════';

ROLLBACK;

PROMPT '✅ Rollback effectué - Base propre';
PROMPT '';
PROMPT '═══════════════════════════════════════════════════════════';
PROMPT '✅ TOUS LES TESTS SONT PASSÉS';
PROMPT '═══════════════════════════════════════════════════════════';

EXIT;
