-- ============================================================
-- PROJET 3 - HOTEL ET RESERVATIONS
-- pkg_hotel.sql
-- Auteur: Groupe 1
-- Date: 2026
-- Description: Package de gestion d'hôtel
-- ============================================================

-- ============================================================
-- SPECIFICATION DU PACKAGE
-- ============================================================

CREATE OR REPLACE PACKAGE pkg_hotel AS
    -- Constantes (c_)
    c_vip_remise CONSTANT NUMBER := 0.10;
    c_penalite_annulation CONSTANT NUMBER := 0.30;
    c_delai_annulation_heures CONSTANT NUMBER := 48;
    
    -- SQL Dynamique
    PROCEDURE compter_lignes(p_table_name IN VARCHAR2);
    
    -- Fonction pour calculer les nuits
    FUNCTION nb_nuits(p_resa_id IN reservation.id%TYPE) RETURN NUMBER;
    
    -- Procédure de réservation
    PROCEDURE reserver(
        p_client_id IN client_hotel.id%TYPE,
        p_chambre_no IN chambre.numero%TYPE,
        p_date_arrivee IN DATE,
        p_date_depart IN DATE,
        p_nb_personnes IN reservation.nb_personnes%TYPE DEFAULT 1
    );
    
    -- Procédure d'annulation
    PROCEDURE annuler(p_resa_id IN reservation.id%TYPE);
    
    -- Curseur REF CURSOR
    FUNCTION chambres_libres(p_date IN DATE) RETURN SYS_REFCURSOR;
    
    -- Statistiques
    PROCEDURE statistiques;
    
    -- BULK COLLECT + FORALL
    PROCEDURE charger_reservations_massif(
        p_client_ids IN SYS.ODCINUMBERLIST,
        p_chambre_nos IN SYS.ODCINUMBERLIST,
        p_arrivees IN SYS.ODCIDATELIST,
        p_departs IN SYS.ODCIDATELIST,
        p_nb_personnes IN SYS.ODCINUMBERLIST
    );
    
END pkg_hotel;
/

-- ============================================================
-- CORPS DU PACKAGE
-- ============================================================

CREATE OR REPLACE PACKAGE BODY pkg_hotel AS

    -- ============================================================
    -- compter_lignes - SQL Dynamique
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Compte les lignes d'une table via EXECUTE IMMEDIATE
    -- Paramètres: p_table_name - nom de la table
    -- ============================================================
    PROCEDURE compter_lignes(p_table_name IN VARCHAR2) IS
        l_count NUMBER;
        l_sql VARCHAR2(200);
    BEGIN
        l_sql := 'SELECT COUNT(*) FROM ' || p_table_name;
        EXECUTE IMMEDIATE l_sql INTO l_count;
        DBMS_OUTPUT.PUT_LINE('📊 Table ' || p_table_name || ' : ' || l_count || ' lignes');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('❌ Erreur: ' || SQLERRM);
    END compter_lignes;

    -- ============================================================
    -- nb_nuits - Calcule le nombre de nuits
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Retourne le nombre de nuits d'une réservation
    -- Paramètres: p_resa_id - ID de la réservation
    -- Retour: Nombre de nuits
    -- ============================================================
    FUNCTION nb_nuits(p_resa_id IN reservation.id%TYPE) RETURN NUMBER IS
        l_reservation reservation%ROWTYPE;
        l_nb_nuits NUMBER;
    BEGIN
        SELECT * INTO l_reservation
        FROM reservation
        WHERE id = p_resa_id;
        
        l_nb_nuits := l_reservation.date_depart - l_reservation.date_arrivee;
        
        IF l_nb_nuits <= 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Date de départ doit être > date d''arrivée');
        END IF;
        
        RETURN l_nb_nuits;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20002, 'Réservation ' || p_resa_id || ' inexistante');
        WHEN TOO_MANY_ROWS THEN
            RAISE_APPLICATION_ERROR(-20003, 'Plusieurs réservations trouvées');
        WHEN OTHERS THEN
            RAISE;
    END nb_nuits;

    -- ============================================================
    -- reserver - Crée une réservation
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Crée une réservation avec toutes les validations
    -- Paramètres: 
    --   p_client_id - ID du client
    --   p_chambre_no - Numéro de chambre
    --   p_date_arrivee - Date d'arrivée
    --   p_date_depart - Date de départ
    --   p_nb_personnes - Nombre de personnes
    -- ============================================================
    PROCEDURE reserver(
        p_client_id IN client_hotel.id%TYPE,
        p_chambre_no IN chambre.numero%TYPE,
        p_date_arrivee IN DATE,
        p_date_depart IN DATE,
        p_nb_personnes IN reservation.nb_personnes%TYPE DEFAULT 1
    ) IS
        l_client client_hotel%ROWTYPE;
        l_chambre chambre%ROWTYPE;
        l_prix_total NUMBER;
        l_nb_nuits NUMBER;
        l_resa_id reservation.id%TYPE;
        l_existe_reservation NUMBER;
    BEGIN
        -- Validation des dates
        IF p_date_arrivee >= p_date_depart THEN
            RAISE_APPLICATION_ERROR(-20004, 'Date d''arrivée doit être antérieure à la date de départ');
        END IF;
        
        -- Vérification de la chambre
        BEGIN
            SELECT * INTO l_chambre
            FROM chambre
            WHERE numero = p_chambre_no;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20005, 'Chambre ' || p_chambre_no || ' inexistante');
            WHEN TOO_MANY_ROWS THEN
                RAISE_APPLICATION_ERROR(-20006, 'Erreur: plusieurs chambres avec le même numéro');
        END;
        
        IF l_chambre.disponible = 'N' THEN
            RAISE_APPLICATION_ERROR(-20007, 'Chambre ' || p_chambre_no || ' temporairement indisponible');
        END IF;
        
        -- Vérification du client
        BEGIN
            SELECT * INTO l_client
            FROM client_hotel
            WHERE id = p_client_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20008, 'Client ' || p_client_id || ' inexistant');
            WHEN TOO_MANY_ROWS THEN
                RAISE_APPLICATION_ERROR(-20009, 'Erreur: plusieurs clients avec le même ID');
        END;
        
        -- Vérification des chevauchements
        SELECT COUNT(*)
        INTO l_existe_reservation
        FROM reservation
        WHERE chambre_no = p_chambre_no
          AND statut IN ('CONFIRMEE', 'TERMINEE')
          AND NOT (p_date_depart <= date_arrivee OR p_date_arrivee >= date_depart);
        
        IF l_existe_reservation > 0 THEN
            RAISE_APPLICATION_ERROR(-20010, 'Chambre déjà réservée sur cette période');
        END IF;
        
        -- Calcul du montant
        l_nb_nuits := p_date_depart - p_date_arrivee;
        l_prix_total := l_nb_nuits * l_chambre.prix_nuit;
        
        -- Remise VIP
        IF l_client.vip = 'O' THEN
            l_prix_total := l_prix_total * (1 - c_vip_remise);
            DBMS_OUTPUT.PUT_LINE('⭐ Remise VIP de 10% appliquée');
        END IF;
        
        -- Création de la réservation
        l_resa_id := seq_reservation.NEXTVAL;
        
        INSERT INTO reservation (
            id, client_id, chambre_no, date_arrivee, date_depart,
            nb_personnes, montant_total, statut
        ) VALUES (
            l_resa_id, p_client_id, p_chambre_no,
            p_date_arrivee, p_date_depart,
            p_nb_personnes, l_prix_total, 'CONFIRMEE'
        );
        
        DBMS_OUTPUT.PUT_LINE('✅ Réservation ' || l_resa_id || ' créée');
        DBMS_OUTPUT.PUT_LINE('💰 Montant: ' || l_prix_total || ' EUR');
        
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END reserver;

    -- ============================================================
    -- annuler - Annule une réservation
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Annule une réservation avec calcul de pénalité
    -- Paramètres: p_resa_id - ID de la réservation
    -- ============================================================
    PROCEDURE annuler(p_resa_id IN reservation.id%TYPE) IS
        l_reservation reservation%ROWTYPE;
        l_heures_avant_arrivee NUMBER;
        l_montant_penalite NUMBER;
    BEGIN
        BEGIN
            SELECT * INTO l_reservation
            FROM reservation
            WHERE id = p_resa_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20011, 'Réservation ' || p_resa_id || ' inexistante');
            WHEN TOO_MANY_ROWS THEN
                RAISE_APPLICATION_ERROR(-20012, 'Erreur: plusieurs réservations avec le même ID');
        END;
        
        IF l_reservation.statut = 'ANNULEE' THEN
            RAISE_APPLICATION_ERROR(-20013, 'Réservation déjà annulée');
        END IF;
        
        IF l_reservation.statut = 'TERMINEE' THEN
            RAISE_APPLICATION_ERROR(-20014, 'Impossible d''annuler une réservation terminée');
        END IF;
        
        l_heures_avant_arrivee := (l_reservation.date_arrivee - SYSDATE) * 24;
        
        IF l_heures_avant_arrivee < c_delai_annulation_heures AND l_heures_avant_arrivee > 0 THEN
            l_montant_penalite := l_reservation.montant_total * c_penalite_annulation;
            DBMS_OUTPUT.PUT_LINE('⚠️ Pénalité: ' || l_montant_penalite || ' EUR (< 48h)');
        ELSIF l_heures_avant_arrivee <= 0 THEN
            l_montant_penalite := l_reservation.montant_total;
            DBMS_OUTPUT.PUT_LINE('⚠️ Pénalité totale: ' || l_montant_penalite || ' EUR');
        ELSE
            DBMS_OUTPUT.PUT_LINE('✅ Annulation sans pénalité (> 48h)');
        END IF;
        
        UPDATE reservation
        SET statut = 'ANNULEE'
        WHERE id = p_resa_id;
        
        DBMS_OUTPUT.PUT_LINE('✅ Réservation ' || p_resa_id || ' annulée');
        
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END annuler;

    -- ============================================================
    -- chambres_libres - Curseur des chambres disponibles
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Retourne un REF CURSOR des chambres disponibles
    -- Paramètres: p_date - Date de recherche
    -- Retour: SYS_REFCURSOR
    -- ============================================================
    FUNCTION chambres_libres(p_date IN DATE) RETURN SYS_REFCURSOR IS
        l_cursor SYS_REFCURSOR;
    BEGIN
        OPEN l_cursor FOR
            SELECT c.numero, c.type_ch, c.etage, c.prix_nuit
            FROM chambre c
            WHERE c.disponible = 'O'
              AND NOT EXISTS (
                  SELECT 1
                  FROM reservation r
                  WHERE r.chambre_no = c.numero
                    AND r.statut IN ('CONFIRMEE', 'TERMINEE')
                    AND p_date BETWEEN r.date_arrivee AND r.date_depart - 1
              )
            ORDER BY c.numero;
            
        RETURN l_cursor;
    END chambres_libres;

    -- ============================================================
    -- statistiques - Affiche les statistiques
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Affiche taux d'occupation et revenu mensuel
    -- ============================================================
    PROCEDURE statistiques IS
        CURSOR c_taux_occupation IS
            SELECT 
                c.type_ch,
                COUNT(DISTINCT c.numero) AS total_chambres,
                COUNT(DISTINCT r.chambre_no) AS chambres_occupees,
                ROUND(COUNT(DISTINCT r.chambre_no) / COUNT(DISTINCT c.numero) * 100, 2) AS taux_occupation
            FROM chambre c
            LEFT JOIN reservation r ON c.numero = r.chambre_no
                AND r.statut IN ('CONFIRMEE', 'TERMINEE')
                AND EXTRACT(MONTH FROM r.date_arrivee) = EXTRACT(MONTH FROM SYSDATE)
                AND EXTRACT(YEAR FROM r.date_arrivee) = EXTRACT(YEAR FROM SYSDATE)
            GROUP BY c.type_ch
            ORDER BY c.type_ch;
            
        l_revenu_mensuel NUMBER;
        
    BEGIN
        DBMS_OUTPUT.PUT_LINE('========================================');
        DBMS_OUTPUT.PUT_LINE('📊 STATISTIQUES HOTEL - ' || TO_CHAR(SYSDATE, 'MM/YYYY'));
        DBMS_OUTPUT.PUT_LINE('========================================');
        DBMS_OUTPUT.PUT_LINE('');
        
        DBMS_OUTPUT.PUT_LINE('TAUX D''OCCUPATION PAR TYPE:');
        DBMS_OUTPUT.PUT_LINE('----------------------------------------');
        
        FOR l_rec IN c_taux_occupation LOOP
            DBMS_OUTPUT.PUT_LINE(
                l_rec.type_ch || 
                ' : ' || l_rec.taux_occupation || '%' ||
                ' (' || l_rec.chambres_occupees || '/' || l_rec.total_chambres || ')'
            );
        END LOOP;
        
        SELECT NVL(SUM(montant_total), 0)
        INTO l_revenu_mensuel
        FROM reservation
        WHERE statut IN ('CONFIRMEE', 'TERMINEE')
          AND EXTRACT(MONTH FROM date_arrivee) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM date_arrivee) = EXTRACT(YEAR FROM SYSDATE);
          
        DBMS_OUTPUT.PUT_LINE('');
        DBMS_OUTPUT.PUT_LINE('💰 REVENU MENSUEL: ' || l_revenu_mensuel || ' EUR');
        DBMS_OUTPUT.PUT_LINE('========================================');
        
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END statistiques;

    -- ============================================================
    -- charger_reservations_massif - BULK COLLECT + FORALL
    -- Auteur: Groupe 1
    -- Date: 2026
    -- Description: Chargement massif de réservations
    -- Paramètres: Collections de données
    -- ============================================================
    PROCEDURE charger_reservations_massif(
        p_client_ids IN SYS.ODCINUMBERLIST,
        p_chambre_nos IN SYS.ODCINUMBERLIST,
        p_arrivees IN SYS.ODCIDATELIST,
        p_departs IN SYS.ODCIDATELIST,
        p_nb_personnes IN SYS.ODCINUMBERLIST
    ) IS
        TYPE t_resa_record IS RECORD (
            id reservation.id%TYPE,
            client_id reservation.client_id%TYPE,
            chambre_no reservation.chambre_no%TYPE,
            date_arrivee reservation.date_arrivee%TYPE,
            date_depart reservation.date_depart%TYPE,
            nb_personnes reservation.nb_personnes%TYPE,
            montant_total reservation.montant_total%TYPE,
            statut reservation.statut%TYPE
        );
        TYPE t_resa_table IS TABLE OF t_resa_record;
        l_reservations t_resa_table := t_resa_table();
        l_chambre_prix chambre.prix_nuit%TYPE;
    BEGIN
        IF p_client_ids.COUNT != p_chambre_nos.COUNT 
           OR p_client_ids.COUNT != p_arrivees.COUNT
           OR p_client_ids.COUNT != p_departs.COUNT
           OR p_client_ids.COUNT != p_nb_personnes.COUNT THEN
            RAISE_APPLICATION_ERROR(-20015, 'Les tableaux doivent avoir la même taille');
        END IF;
        
        FOR i IN 1..p_client_ids.COUNT LOOP
            BEGIN
                SELECT prix_nuit INTO l_chambre_prix
                FROM chambre
                WHERE numero = p_chambre_nos(i);
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20016, 'Chambre ' || p_chambre_nos(i) || ' inexistante');
            END;
            
            l_reservations.EXTEND;
            l_reservations(i).id := seq_reservation.NEXTVAL;
            l_reservations(i).client_id := p_client_ids(i);
            l_reservations(i).chambre_no := p_chambre_nos(i);
            l_reservations(i).date_arrivee := p_arrivees(i);
            l_reservations(i).date_depart := p_departs(i);
            l_reservations(i).nb_personnes := p_nb_personnes(i);
            l_reservations(i).montant_total := (p_departs(i) - p_arrivees(i)) * l_chambre_prix;
            l_reservations(i).statut := 'CONFIRMEE';
        END LOOP;
        
        -- Insertion en masse avec FORALL
        FORALL i IN 1..l_reservations.COUNT
            INSERT INTO reservation (
                id, client_id, chambre_no, date_arrivee, date_depart,
                nb_personnes, montant_total, statut
            ) VALUES (
                l_reservations(i).id,
                l_reservations(i).client_id,
                l_reservations(i).chambre_no,
                l_reservations(i).date_arrivee,
                l_reservations(i).date_depart,
                l_reservations(i).nb_personnes,
                l_reservations(i).montant_total,
                l_reservations(i).statut
            );
            
        DBMS_OUTPUT.PUT_LINE('✅ ' || l_reservations.COUNT || ' réservations chargées en masse');
        
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END charger_reservations_massif;

END pkg_hotel;
/

PROMPT '✅ Package pkg_hotel créé';
/
