-- ============================================================
-- PROJET 3 - HOTEL ET RESERVATIONS
-- triggers.sql
-- Auteur: Groupe 1
-- Date: 2026
-- Description: Triggers composés pour l'audit
-- ============================================================

-- ============================================================
-- Trigger composé pour l'audit des réservations
-- ============================================================
CREATE OR REPLACE TRIGGER trg_audit_reservation
    FOR INSERT OR UPDATE OR DELETE ON reservation
    COMPOUND TRIGGER
    
    -- Type pour stocker les données d'audit
    TYPE t_audit_row IS RECORD (
        action VARCHAR2(10),
        client_id reservation.client_id%TYPE,
        chambre_no reservation.chambre_no%TYPE
    );
    
    -- Table PL/SQL pour collecter les données
    TYPE t_audit_table IS TABLE OF t_audit_row;
    g_audit_data t_audit_table := t_audit_table();
    g_utilisateur VARCHAR2(30) := USER;
    
    -- ============================================================
    -- BEFORE EACH ROW - Collecte des données
    -- ============================================================
    BEFORE EACH ROW IS
    BEGIN
        g_audit_data.EXTEND;
        
        IF INSERTING THEN
            g_audit_data(g_audit_data.COUNT).action := 'INSERT';
            g_audit_data(g_audit_data.COUNT).client_id := :NEW.client_id;
            g_audit_data(g_audit_data.COUNT).chambre_no := :NEW.chambre_no;
        ELSIF UPDATING THEN
            IF :OLD.statut != :NEW.statut 
               OR :OLD.chambre_no != :NEW.chambre_no
               OR :OLD.client_id != :NEW.client_id THEN
                g_audit_data(g_audit_data.COUNT).action := 'UPDATE';
                g_audit_data(g_audit_data.COUNT).client_id := :NEW.client_id;
                g_audit_data(g_audit_data.COUNT).chambre_no := :NEW.chambre_no;
            ELSE
                g_audit_data.TRIM;
            END IF;
        ELSIF DELETING THEN
            g_audit_data(g_audit_data.COUNT).action := 'DELETE';
            g_audit_data(g_audit_data.COUNT).client_id := :OLD.client_id;
            g_audit_data(g_audit_data.COUNT).chambre_no := :OLD.chambre_no;
        END IF;
    END BEFORE EACH ROW;
    
    -- ============================================================
    -- AFTER STATEMENT - Insertion dans journal_resa
    -- ============================================================
    AFTER STATEMENT IS
        l_id NUMBER;
    BEGIN
        FOR i IN 1..g_audit_data.COUNT LOOP
            l_id := seq_journal.NEXTVAL;
            INSERT INTO journal_resa (
                id, action, client_id, chambre_no, date_action, utilisateur
            ) VALUES (
                l_id,
                g_audit_data(i).action,
                g_audit_data(i).client_id,
                g_audit_data(i).chambre_no,
                SYSTIMESTAMP,
                g_utilisateur
            );
        END LOOP;
        
        g_audit_data.DELETE;
    END AFTER STATEMENT;
    
END trg_audit_reservation;
/

-- ============================================================
-- Trigger de mise à jour de disponibilité
-- ============================================================
CREATE OR REPLACE TRIGGER trg_update_chambre_dispo
    AFTER UPDATE OF statut ON reservation
    FOR EACH ROW
BEGIN
    IF :NEW.statut = 'ANNULEE' AND :OLD.statut != 'ANNULEE' THEN
        UPDATE chambre
        SET disponible = 'O'
        WHERE numero = :NEW.chambre_no;
    END IF;
END trg_update_chambre_dispo;
/

PROMPT '✅ Triggers créés';
/
